MyPortal Android prototype
- Package: com.example.myportal
- App name: MyPortal
- Theme color: Blue

How to open:
1. Open Android Studio.
2. Choose 'Open' and select the folder: MyPortal_android_project/app
3. Sync Gradle (you may need to update gradle plugin versions).
4. Build & Run on an emulator or device.

Notes:
- This is a minimal prototype. Room uses allowMainThreadQueries for simplicity.
- Import CSV via Import Marks button (file picker). CSV should have lines: ModuleName,Mark
