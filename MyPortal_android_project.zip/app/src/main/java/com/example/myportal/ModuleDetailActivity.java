package com.example.myportal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.widget.TextView;

import com.example.myportal.db.AppDatabase;
import com.example.myportal.db.Module;

public class ModuleDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_detail);

        int id = getIntent().getIntExtra("id", -1);
        AppDatabase db = Room.databaseBuilder(this, AppDatabase.class, "myportal.db")
                .allowMainThreadQueries().build();
        Module m = db.moduleDao().getById(id);

        ((TextView)findViewById(R.id.txtModName)).setText(m.moduleName);
        ((TextView)findViewById(R.id.txtModMark)).setText("Mark: " + m.mark + "%");
        ((TextView)findViewById(R.id.txtModGrade)).setText("Grade: " + m.grade);
    }
}
