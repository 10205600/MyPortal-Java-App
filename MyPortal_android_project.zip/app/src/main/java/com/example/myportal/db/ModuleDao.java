package com.example.myportal.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;

import java.util.List;

@Dao
public interface ModuleDao {
    @Insert
    void insert(Module module);

    @Query("DELETE FROM modules")
    void clear();

    @Query("SELECT * FROM modules")
    List<Module> getAll();

    @Query("SELECT * FROM modules WHERE id=:id")
    Module getById(int id);
}
