package com.example.myportal;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myportal.db.AppDatabase;
import com.example.myportal.db.Module;
import com.example.myportal.db.ModuleDao;
import com.example.myportal.db.Student;
import com.example.myportal.db.StudentDao;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private AppDatabase db;
    private ModuleDao moduleDao;
    private StudentDao studentDao;

    private List<Module> modules = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private ListView listView;
    private ActivityResultLauncher<String[]> filePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(this, AppDatabase.class, "myportal.db")
                .allowMainThreadQueries()
                .build();
        moduleDao = db.moduleDao();
        studentDao = db.studentDao();

        EditText edtName = findViewById(R.id.edtName);
        EditText edtStudentNo = findViewById(R.id.edtStudentNo);
        Button saveProfileBtn = findViewById(R.id.saveProfileBtn);
        TextView statsTxt = findViewById(R.id.txtStats);
        Button importBtn = findViewById(R.id.importCsvBtn);
        listView = findViewById(R.id.modulesList);

        // load profile
        Student p = studentDao.getProfile();
        if (p != null) {
            edtName.setText(p.name);
            edtStudentNo.setText(p.studentNumber);
        }

        saveProfileBtn.setOnClickListener(v -> {
            Student s = new Student();
            s.name = edtName.getText().toString();
            s.studentNumber = edtStudentNo.getText().toString();
            studentDao.save(s);
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
        });

        loadModules();
        updateStats(statsTxt);

        filePicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        importCSV(uri, statsTxt);
                    }
                });

        importBtn.setOnClickListener(v ->
                filePicker.launch(new String[] { "text/*", "text/comma-separated-values", "application/csv" })
        );

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Module m = modules.get(position);
            Intent i = new Intent(MainActivity.this, ModuleDetailActivity.class);
            i.putExtra("id", m.id);
            startActivity(i);
        });
    }

    private void importCSV(Uri uri, TextView statsTxt) {
        moduleDao.clear();
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                String[] split = line.split(",");
                if (split.length >= 2) {
                    Module m = new Module();
                    m.moduleName = split[0].trim();
                    try {
                        m.mark = Integer.parseInt(split[1].trim());
                    } catch (NumberFormatException ex) {
                        m.mark = 0;
                    }
                    m.grade = gradeCalc(m.mark);
                    moduleDao.insert(m);
                }
            }
            br.close();
        } catch (Exception e) {
            Toast.makeText(this, "CSV import error", Toast.LENGTH_SHORT).show();
        }
        loadModules();
        updateStats(statsTxt);
        Toast.makeText(this, "Imported", Toast.LENGTH_SHORT).show();
    }

    private String gradeCalc(int mark) {
        if (mark >= 90) return "A+";
        if (mark >= 80) return "A";
        if (mark >= 70) return "B";
        if (mark >= 60) return "C";
        if (mark >= 50) return "D";
        return "F";
    }

    private void loadModules() {
        modules.clear();
        List<Module> all = moduleDao.getAll();
        if (all != null) modules.addAll(all);
        ArrayList<String> list = new ArrayList<>();
        for (Module m : modules) {
            list.add(m.moduleName + " - " + m.mark + "% (" + m.grade + ")");
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
    }

    private void updateStats(TextView statsTxt) {
        if (modules.isEmpty()) {
            statsTxt.setText("Average: -- | GPA: --");
            return;
        }
        double total = 0;
        for (Module m : modules) total += m.mark;
        double avg = total / modules.size();
        double gpa = avg / 20.0; // simple scale 0-5
        statsTxt.setText(String.format("Average: %.1f | GPA: %.2f", avg, gpa));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadModules();
    }
}
