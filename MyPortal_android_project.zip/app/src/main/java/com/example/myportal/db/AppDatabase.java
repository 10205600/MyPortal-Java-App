package com.example.myportal.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Module.class, Student.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract ModuleDao moduleDao();
    public abstract StudentDao studentDao();
}
