package com.example.myportal.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface StudentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(Student student);

    @Query("SELECT * FROM student WHERE id=1")
    Student getProfile();
}
