package com.example.myportal.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "student")
public class Student {
    @PrimaryKey
    public int id = 1;
    public String name;
    public String studentNumber;
}
