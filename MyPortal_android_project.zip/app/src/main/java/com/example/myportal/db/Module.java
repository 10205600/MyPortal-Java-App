package com.example.myportal.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "modules")
public class Module {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String moduleName;
    public int mark;
    public String grade;
}
